#include <iostream>
#include <cmath>
using namespace std;

int main(){
    float praktikum = 75, uts = 70, uas = 88, nilaiAkhir;
    nilaiAkhir = (praktikum* 0.2) + (uts*0.3) + (uas*0.5);
    cout << "Nilai praktikum anda adalah " << praktikum << endl;
    cout << "Nilai UTS anda adalah " << uts << endl;
    cout << "Nilai UAS anda adalah " << uas<< endl;
    cout << "Nilai akhir anda adalah " << nilaiAkhir << endl;

    return 0;
}
